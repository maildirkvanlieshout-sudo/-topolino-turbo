FLAPPIES TOPOLINO RACE

Upload naar GitHub:
- index.html in de hoofdmap
- de map assets ernaast

De game bevat:
- Flappie als driver
- Ghurt als co-driver / speciale Ghurt Power
- jullie echte Topolino-video als intro
- drie racewerelden
- turbo, schild, combo's, score/record
- toetsenbord + mobiele bediening
- gegenereerde muziek en geluidseffecten
